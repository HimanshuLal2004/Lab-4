﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_4_9pm
{
    public partial class Form1 : Form
    {
        double number1;
        double number2;
        double result;
        char operation;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }

        private void btn_equal_Click(object sender, EventArgs e)
        {
            number2 = double.Parse(textBox1.Text);
            if (operation == '+')
            {
               result = number1 + number2;
            }
            else if ( operation == '-')
            {
                result = number1 - number2;
            }
            else if ( operation == '*')
            {
                result = number1 * number2;
            }
            else if( operation == '/')
            {
                result = number1 / number2;
            }
            else if(operation == '%')
            {
                result = number1 / 100;
            }

            textBox1.Text = result + "";
        }

        private void btn_plus_Click(object sender, EventArgs e)
        {
            operation = '+';
            number1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void btn_minus_Click(object sender, EventArgs e)
        {
            operation = '-';
            number1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            operation = '*';
            number1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            operation = '/';
            number1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void btn_ac_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            number1 = 0;
            number2 = 0;
            result = 0; 
        }

        private void button_plusminus_Click(object sender, EventArgs e)
        {
            number1 = double.Parse(textBox1.Text);
            if (textBox1.Text[0] == '-')
            {
                textBox1.Text = "+" + number1;
            }
            else
            {
                textBox1.Text = "-" + number1;
            }
        }

        private void btn_percentage_Click(object sender, EventArgs e)
        {
            operation = '%';
            number1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void btn_dot_Click(object sender, EventArgs e)
        {
            if(textBox1.Text is null)
            {
                textBox1.Text = textBox1.Text + '.' ;
            }
            else
            {
                textBox1.Text = textBox1.Text + "." + "";
            }
            
        }
    }
}
