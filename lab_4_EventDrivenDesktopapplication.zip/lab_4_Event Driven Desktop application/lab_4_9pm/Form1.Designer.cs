﻿namespace lab_4_9pm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_ac = new System.Windows.Forms.Button();
            this.button_plusminus = new System.Windows.Forms.Button();
            this.btn_percentage = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_divide = new System.Windows.Forms.Button();
            this.btn_dot = new System.Windows.Forms.Button();
            this.btn_equal = new System.Windows.Forms.Button();
            this.btn_plus = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_multiply = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_ac
            // 
            this.btn_ac.AutoSize = true;
            this.btn_ac.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ac.BackgroundImage")));
            this.btn_ac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ac.FlatAppearance.BorderSize = 0;
            this.btn_ac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ac.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ac.Location = new System.Drawing.Point(29, 96);
            this.btn_ac.Name = "btn_ac";
            this.btn_ac.Size = new System.Drawing.Size(90, 78);
            this.btn_ac.TabIndex = 0;
            this.btn_ac.Text = "AC";
            this.btn_ac.UseVisualStyleBackColor = true;
            this.btn_ac.Click += new System.EventHandler(this.btn_ac_Click);
            // 
            // button_plusminus
            // 
            this.button_plusminus.AutoSize = true;
            this.button_plusminus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_plusminus.BackgroundImage")));
            this.button_plusminus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_plusminus.FlatAppearance.BorderSize = 0;
            this.button_plusminus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_plusminus.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_plusminus.Location = new System.Drawing.Point(125, 96);
            this.button_plusminus.Name = "button_plusminus";
            this.button_plusminus.Size = new System.Drawing.Size(90, 78);
            this.button_plusminus.TabIndex = 2;
            this.button_plusminus.Text = "+/-";
            this.button_plusminus.UseVisualStyleBackColor = true;
            this.button_plusminus.Click += new System.EventHandler(this.button_plusminus_Click);
            // 
            // btn_percentage
            // 
            this.btn_percentage.AutoSize = true;
            this.btn_percentage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_percentage.BackgroundImage")));
            this.btn_percentage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_percentage.FlatAppearance.BorderSize = 0;
            this.btn_percentage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_percentage.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_percentage.Location = new System.Drawing.Point(221, 96);
            this.btn_percentage.Name = "btn_percentage";
            this.btn_percentage.Size = new System.Drawing.Size(90, 78);
            this.btn_percentage.TabIndex = 3;
            this.btn_percentage.Text = "%";
            this.btn_percentage.UseVisualStyleBackColor = true;
            this.btn_percentage.Click += new System.EventHandler(this.btn_percentage_Click);
            // 
            // btn_7
            // 
            this.btn_7.AutoSize = true;
            this.btn_7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_7.BackgroundImage")));
            this.btn_7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_7.FlatAppearance.BorderSize = 0;
            this.btn_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_7.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_7.Location = new System.Drawing.Point(29, 190);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(90, 78);
            this.btn_7.TabIndex = 4;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = true;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // btn_2
            // 
            this.btn_2.AutoSize = true;
            this.btn_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_2.BackgroundImage")));
            this.btn_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_2.FlatAppearance.BorderSize = 0;
            this.btn_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_2.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_2.Location = new System.Drawing.Point(125, 383);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(90, 78);
            this.btn_2.TabIndex = 5;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = true;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_1
            // 
            this.btn_1.AutoSize = true;
            this.btn_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_1.BackgroundImage")));
            this.btn_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_1.FlatAppearance.BorderSize = 0;
            this.btn_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_1.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_1.Location = new System.Drawing.Point(29, 383);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(90, 78);
            this.btn_1.TabIndex = 6;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_6
            // 
            this.btn_6.AutoSize = true;
            this.btn_6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_6.BackgroundImage")));
            this.btn_6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_6.FlatAppearance.BorderSize = 0;
            this.btn_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_6.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_6.Location = new System.Drawing.Point(221, 286);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(90, 78);
            this.btn_6.TabIndex = 7;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = true;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_5
            // 
            this.btn_5.AutoSize = true;
            this.btn_5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_5.BackgroundImage")));
            this.btn_5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_5.FlatAppearance.BorderSize = 0;
            this.btn_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_5.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_5.Location = new System.Drawing.Point(125, 286);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(90, 78);
            this.btn_5.TabIndex = 8;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = true;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_4
            // 
            this.btn_4.AutoSize = true;
            this.btn_4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_4.BackgroundImage")));
            this.btn_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_4.FlatAppearance.BorderSize = 0;
            this.btn_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_4.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_4.Location = new System.Drawing.Point(29, 286);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(90, 78);
            this.btn_4.TabIndex = 9;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = true;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_9
            // 
            this.btn_9.AutoSize = true;
            this.btn_9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_9.BackgroundImage")));
            this.btn_9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_9.FlatAppearance.BorderSize = 0;
            this.btn_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_9.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_9.Location = new System.Drawing.Point(221, 190);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(90, 78);
            this.btn_9.TabIndex = 10;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = true;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_8
            // 
            this.btn_8.AutoSize = true;
            this.btn_8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_8.BackgroundImage")));
            this.btn_8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_8.FlatAppearance.BorderSize = 0;
            this.btn_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_8.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_8.Location = new System.Drawing.Point(125, 190);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(90, 78);
            this.btn_8.TabIndex = 11;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = true;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_3
            // 
            this.btn_3.AutoSize = true;
            this.btn_3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_3.BackgroundImage")));
            this.btn_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_3.FlatAppearance.BorderSize = 0;
            this.btn_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_3.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_3.Location = new System.Drawing.Point(221, 383);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(90, 78);
            this.btn_3.TabIndex = 12;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = true;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_divide
            // 
            this.btn_divide.AutoSize = true;
            this.btn_divide.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_divide.BackgroundImage")));
            this.btn_divide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_divide.FlatAppearance.BorderSize = 0;
            this.btn_divide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_divide.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_divide.Location = new System.Drawing.Point(317, 96);
            this.btn_divide.Name = "btn_divide";
            this.btn_divide.Size = new System.Drawing.Size(90, 78);
            this.btn_divide.TabIndex = 13;
            this.btn_divide.Text = "÷";
            this.btn_divide.UseVisualStyleBackColor = true;
            this.btn_divide.Click += new System.EventHandler(this.btn_divide_Click);
            // 
            // btn_dot
            // 
            this.btn_dot.AutoSize = true;
            this.btn_dot.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_dot.BackgroundImage")));
            this.btn_dot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_dot.FlatAppearance.BorderSize = 0;
            this.btn_dot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dot.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dot.Location = new System.Drawing.Point(221, 478);
            this.btn_dot.Name = "btn_dot";
            this.btn_dot.Size = new System.Drawing.Size(90, 78);
            this.btn_dot.TabIndex = 14;
            this.btn_dot.Text = ".";
            this.btn_dot.UseVisualStyleBackColor = true;
            this.btn_dot.Click += new System.EventHandler(this.btn_dot_Click);
            // 
            // btn_equal
            // 
            this.btn_equal.AutoSize = true;
            this.btn_equal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_equal.BackgroundImage")));
            this.btn_equal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_equal.FlatAppearance.BorderSize = 0;
            this.btn_equal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_equal.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_equal.Location = new System.Drawing.Point(317, 467);
            this.btn_equal.Name = "btn_equal";
            this.btn_equal.Size = new System.Drawing.Size(90, 78);
            this.btn_equal.TabIndex = 15;
            this.btn_equal.Text = "=";
            this.btn_equal.UseVisualStyleBackColor = true;
            this.btn_equal.Click += new System.EventHandler(this.btn_equal_Click);
            // 
            // btn_plus
            // 
            this.btn_plus.AutoSize = true;
            this.btn_plus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_plus.BackgroundImage")));
            this.btn_plus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_plus.FlatAppearance.BorderSize = 0;
            this.btn_plus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_plus.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_plus.Location = new System.Drawing.Point(317, 383);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(90, 78);
            this.btn_plus.TabIndex = 16;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = true;
            this.btn_plus.Click += new System.EventHandler(this.btn_plus_Click);
            // 
            // btn_minus
            // 
            this.btn_minus.AutoSize = true;
            this.btn_minus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_minus.BackgroundImage")));
            this.btn_minus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_minus.FlatAppearance.BorderSize = 0;
            this.btn_minus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_minus.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_minus.Location = new System.Drawing.Point(317, 286);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(90, 78);
            this.btn_minus.TabIndex = 17;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = true;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_Click);
            // 
            // btn_multiply
            // 
            this.btn_multiply.AutoSize = true;
            this.btn_multiply.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_multiply.BackgroundImage")));
            this.btn_multiply.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_multiply.FlatAppearance.BorderSize = 0;
            this.btn_multiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_multiply.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_multiply.Location = new System.Drawing.Point(317, 190);
            this.btn_multiply.Name = "btn_multiply";
            this.btn_multiply.Size = new System.Drawing.Size(90, 78);
            this.btn_multiply.TabIndex = 18;
            this.btn_multiply.Text = "×";
            this.btn_multiply.UseVisualStyleBackColor = true;
            this.btn_multiply.Click += new System.EventHandler(this.btn_multiply_Click);
            // 
            // btn_0
            // 
            this.btn_0.AutoSize = true;
            this.btn_0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_0.BackgroundImage")));
            this.btn_0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_0.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_0.Location = new System.Drawing.Point(29, 478);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(186, 78);
            this.btn_0.TabIndex = 19;
            this.btn_0.Text = "0";
            this.btn_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_0.UseVisualStyleBackColor = true;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(29, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(378, 22);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(431, 573);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_multiply);
            this.Controls.Add(this.btn_minus);
            this.Controls.Add(this.btn_plus);
            this.Controls.Add(this.btn_equal);
            this.Controls.Add(this.btn_dot);
            this.Controls.Add(this.btn_divide);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_percentage);
            this.Controls.Add(this.button_plusminus);
            this.Controls.Add(this.btn_ac);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ac;
        private System.Windows.Forms.Button button_plusminus;
        private System.Windows.Forms.Button btn_percentage;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_divide;
        private System.Windows.Forms.Button btn_dot;
        private System.Windows.Forms.Button btn_equal;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_multiply;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.TextBox textBox1;
    }
}

